# x / y-3
# 1 / (x+y)
# the square root of x to the 6th plus y to the 5th
# absolute value of x + y

x = -13
y = 2.0
#print(x / y-3)
#print(1 / (x+y))
#print(Math.sqrt(x**6+y**5))
print((x+y).abs)