count = 0
total = 0
while temp = gets
   total += Integer(temp)
   count += 1
end
puts total / count