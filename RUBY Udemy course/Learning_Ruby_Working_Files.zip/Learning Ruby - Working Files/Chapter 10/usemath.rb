require "./MathList"

print(MathList.add(1,2,3))
print("\n")
print(MathList.sub(10,2,4,3))
print("\n")
print(MathList.mul(1,2,3,4,5))