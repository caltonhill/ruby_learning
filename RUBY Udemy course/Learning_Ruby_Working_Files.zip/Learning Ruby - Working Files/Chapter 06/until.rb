#until comparison
#   statements
#end

#count = 1
#until count > 5
#   puts("Hello, world")
#   count += 1
#end

sum = 0
number = 1
until number > 10
   sum += number
   number += 1
end
puts(sum)
