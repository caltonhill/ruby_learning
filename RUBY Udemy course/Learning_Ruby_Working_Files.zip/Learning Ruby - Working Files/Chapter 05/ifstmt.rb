#if comparison (relational expression)
#   statements
#end

grade = gets
grade = Integer(grade)
if grade >= 70
   puts("pass")
end